using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Detectionplane : EnemyBase
{
    // Start is called before the first frame update
    void Start()
    {
        Speed = 10f;
        Hp = 3;
    }
    public override void Movement()
    {
        transform.Translate(Vector3.left * Time.deltaTime * Speed / 2, Space.World);
    }
    public override void relive()
    {
        transform.position = new Vector3(15f, Random.Range(-2.5f, 3.5f), 0);
    }
}
