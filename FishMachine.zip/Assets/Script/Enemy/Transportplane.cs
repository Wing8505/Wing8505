using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Transportplane : EnemyBase
{
    float timer = 0;
    void Start()
    {
        Speed = 9f;
        Hp = 5;
    }
    public override void Movement()
    {
        float x = transform.position.x;
        if(x >=-10 && x <=10 && timer <= 1)
        {
            timer += Time.deltaTime;
            if(timer >= 1){
                Speed *= 1.5f;
            }
        }
        float z = ((transform.eulerAngles.z) + 90) / 360;
        float moveX = -Mathf.Sin(z / 180 * Mathf.PI);
        float moveY = Mathf.Cos(z / 180 * Mathf.PI);
        //transform.Translate(Vector3.left * Time.deltaTime * Speed, Space.World);
        transform.Translate(moveX * Speed * Time.deltaTime, moveY * Speed * Time.deltaTime, 0);
    }
    public override void relive()
    {
        Hp = 5;
        Speed = 9f;
        timer = 0;
        transform.eulerAngles = new Vector3(0, 0, Random.Range(80, 100));
        transform.position = new Vector3(15f, Random.Range(-2.5f, 3.5f), 0);
    }
}
