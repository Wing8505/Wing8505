using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour
{
    public float Speed;
    public int Hp;
    //public int Odds { get; set; }
    //public int MaxCount { get; set; }
    void Update()
    {
        Movement();
    }
    public virtual void Movement(){}
    public virtual void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Bullet")
        {
            Destroy(other.gameObject);
            Hp -= 1;
            if (Hp <= 0)
            {
                //Destroy(this.gameObject);
                relive();
            }
        }
    }
    public virtual void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "DeathLine")
        {
            //Destroy(this.gameObject);
            relive();
        }
    }
    public virtual void relive()
    {
        Hp = 3;
        transform.position = new Vector3(15f, Random.Range(-2.5f, 3.5f), 0);
    }
}
