using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Planemanager : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] GameObject[] Enemies;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.A))
        {
            CreatePlane();
        }
        
    }
    public void CreatePlane()
    {
        int condition = Random.Range(0, Enemies.Length);
        GameObject plane = Instantiate(Enemies[condition], transform);
        plane.transform.position = new Vector3(15f, Random.Range(-2.5f, 3.5f), 0);
    }
}
