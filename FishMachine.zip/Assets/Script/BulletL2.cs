using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletL2 : BulletBase
{
    // Start is called before the first frame update
    void Start()
    {
        ATK = 3;
        
    }

}
