using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletL1 : BulletBase
{
    // Start is called before the first frame update
    void Start()
    {
        ATK=1;
        
    }

}
