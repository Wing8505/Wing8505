using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] float Speed = 10f;
    //[SerializeField] int ATK = 1;
    void Start()
    {
        
    }
    void Update()
    {
        Movement();
    }
    void Movement()
    {
        float z = ((transform.eulerAngles.z) + 90) / 360;
        float moveX = -Mathf.Sin(z / 180 * Mathf.PI);
        float moveY = Mathf.Cos(z / 180 * Mathf.PI);
        transform.Translate(moveX * Speed * Time.deltaTime, moveY * Speed * Time.deltaTime, 0);
    }
    void OnCollisionEnter2D(Collision2D other) 
    { 
        if (other.gameObject.tag == "Border") // 反彈
        {
            ContactPoint2D contactPoint = other.contacts[0];
            Vector2 newDir = Vector2.zero;
            Vector2 curDir = transform.TransformDirection(Vector2.up);
            newDir = Vector2.Reflect(curDir, contactPoint.normal);
            Quaternion rotation = Quaternion.FromToRotation(Vector2.up, newDir);
            transform.rotation = rotation;
        }
        if (other.gameObject.tag == "Enemy")
        {

        }
    }
}
