using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Gun : MonoBehaviour
{
    [SerializeField] KeyCode Fire = KeyCode.Space;
    [SerializeField] KeyCode TurnLeft = KeyCode.LeftArrow;
    [SerializeField] KeyCode TurnRight = KeyCode.RightArrow;
    [SerializeField] KeyCode SwitchBulletUp = KeyCode.X;
    [SerializeField] KeyCode SwitchBulletDown = KeyCode.Z;
    [SerializeField] GameObject[] BulletPrefabs;
    [SerializeField] Sprite[] GunsSprite;
    void Start()
    {

    }
    int bulletIndex = 0;
    void SwitchBullet()
    {
        if (Input.GetKeyDown(SwitchBulletUp)) 
        {
            bulletIndex = (bulletIndex + 1) % 3;
            GetComponent<SpriteRenderer>().sprite = GunsSprite[bulletIndex];
            Debug.Log("current bullet:" + bulletIndex);
        }
        if (Input.GetKeyDown(SwitchBulletDown))
        {
            bulletIndex = (bulletIndex + 2) % 3;
            GetComponent<SpriteRenderer>().sprite = GunsSprite[bulletIndex];
            Debug.Log("current bullet:" + bulletIndex);
        }
    }

    void Update()
    {
        GunRotate();
        Shoot();
        SwitchBullet();
    }
    void Shoot()
    {
        if (Input.GetKeyDown(Fire))
        {
            GameObject bullet = Instantiate(BulletPrefabs[bulletIndex], transform.position, transform.rotation);
            Destroy(bullet, 3f); //3秒後銷毀
        }
    }

    float RotateSpeed = 300f;
    void GunRotate()
    {
        float maxAngle = transform.eulerAngles.z;
        if (maxAngle >= 180) maxAngle -= 360;
        if (Input.GetKey(TurnLeft))
        {
            transform.Rotate(new Vector3(0, 0, RotateSpeed * Time.deltaTime));
            if (maxAngle >= 90)
            {
                transform.Rotate(new Vector3(0, 0, -RotateSpeed * Time.deltaTime));
            }       
        }
        if (Input.GetKey(TurnRight))
        {
            transform.Rotate(new Vector3(0, 0, -RotateSpeed * Time.deltaTime));
            if (maxAngle <= -90)
            {
                transform.Rotate(new Vector3(0, 0, RotateSpeed * Time.deltaTime));
            }
        }

    }
}
